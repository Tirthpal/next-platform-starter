import Link from 'next/link'

export default function Footer({ clinicInfo }) {
  const phone = clinicInfo?.phone || '8288929143'
  const email = clinicInfo?.email || 'drsumeetdentist@gmail.com'
  const address = clinicInfo?.address || 'SCO 167, First Floor, Sector 38-C, Chandigarh 160036'
  const instagram = clinicInfo?.instagramHandle || 'denthealth_38'
  const whatsapp = clinicInfo?.whatsappNumber || '918288929143'

  return (
    <footer style={{ background: '#163835', color: 'rgba(255,255,255,0.65)', padding: '64px 0 28px' }}>
      <div className="container">
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48, marginBottom: 48 }}>

          {/* Brand */}
          <div>
            <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none', marginBottom: 14 }}>
              <div style={{ width: 40, height: 40, background: 'rgba(255,255,255,0.1)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🦷</div>
              <div>
                <div style={{ color: '#fff', fontWeight: 800, fontSize: 16 }}>Smile Dental Clinic</div>
                <div style={{ fontSize: 10, color: 'var(--gold-light)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>Implants · Smile Design · Care</div>
              </div>
            </Link>
            <p style={{ fontSize: 13, lineHeight: 1.8, maxWidth: 260 }}>Chandigarh's most trusted dental clinic — gentle, painless, open 24/7. Led by Dr. Sumeet Gupta, BDS MDS.</p>
            <div style={{ marginTop: 16, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>📍 <span>{address}</span></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>📞 <a href={`tel:+91${phone}`} style={{ color: 'rgba(255,255,255,0.85)', fontWeight: 600 }}>{phone}</a></div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>📷 <a href={`https://instagram.com/${instagram}`} target="_blank" rel="noopener" style={{ color: 'rgba(255,255,255,0.85)', fontWeight: 600 }}>@{instagram}</a></div>
            </div>
          </div>

          {/* Services */}
          <FooterCol title="Services">
            <FooterLink href="/services/dental-implants">Dental Implants</FooterLink>
            <FooterLink href="/services/smile-designing">Smile Designing</FooterLink>
            <FooterLink href="/services/dental-scaling">Scaling & Bleaching</FooterLink>
            <FooterLink href="/services/pediatric-dentistry">Pediatric Dentistry</FooterLink>
            <FooterLink href="/services">All Services</FooterLink>
          </FooterCol>

          {/* Clinic */}
          <FooterCol title="Clinic">
            <FooterLink href="/">Home</FooterLink>
            <FooterLink href="/about">About Us</FooterLink>
            <FooterLink href="/testimonials">Patient Reviews</FooterLink>
            <FooterLink href="/blog">Blog</FooterLink>
            <FooterLink href="/contact">Contact</FooterLink>
          </FooterCol>

          {/* Contact */}
          <FooterCol title="Contact">
            <a href={`tel:+91${phone}`} style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13, display: 'block', marginBottom: 10 }}>📞 {phone}</a>
            <a href={`https://wa.me/${whatsapp}`} style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13, display: 'block', marginBottom: 10 }}>💬 WhatsApp Us</a>
            <a href={`mailto:${email}`} style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13, display: 'block', marginBottom: 10 }}>✉️ {email}</a>
            <span style={{ color: '#10B981', fontWeight: 700, fontSize: 13 }}>⏰ Open 24/7</span>
          </FooterCol>
        </div>

        <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', paddingTop: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10, fontSize: 12 }}>
          <p>© {new Date().getFullYear()} Smile Dental Clinic — Dr. Sumeet Gupta · Sector 38-C, Chandigarh</p>
          <div style={{ display: 'flex', gap: 16 }}>
            <Link href="/studio" style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}>CMS Studio</Link>
            <span style={{ color: 'rgba(255,255,255,0.3)' }}>·</span>
            <span style={{ color: 'rgba(255,255,255,0.3)' }}>Privacy Policy</span>
          </div>
        </div>
      </div>

      <style>{`@media(max-width:768px){ footer > div > div:first-child { grid-template-columns: 1fr 1fr !important; } } @media(max-width:480px){ footer > div > div:first-child { grid-template-columns: 1fr !important; } }`}</style>
    </footer>
  )
}

function FooterCol({ title, children }) {
  return (
    <div>
      <h4 style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 18 }}>{title}</h4>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{children}</div>
    </div>
  )
}

function FooterLink({ href, children }) {
  return <Link href={href} style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13.5, transition: 'color 0.2s' }}>{children}</Link>
}
