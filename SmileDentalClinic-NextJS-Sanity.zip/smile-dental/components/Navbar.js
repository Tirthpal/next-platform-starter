'use client'

import Link from 'next/link'
import { useState } from 'react'

export default function Navbar({ clinicInfo }) {
  const [mobileOpen, setMobileOpen] = useState(false)
  const phone = clinicInfo?.phone || '8288929143'
  const whatsapp = clinicInfo?.whatsappNumber || '918288929143'

  return (
    <>
      {/* Announcement Bar */}
      <div style={{ background: 'var(--teal)', color: 'rgba(255,255,255,0.92)', fontSize: 12.5, textAlign: 'center', padding: '10px 16px', letterSpacing: '0.03em' }}>
        🦷 <span style={{ color: 'var(--gold-light)', fontWeight: 700 }}>Free First Consultation</span> · Open 24/7 · Call <span style={{ color: 'var(--gold-light)', fontWeight: 700 }}>{phone}</span> · SCO 167, Sector 38-C, Chandigarh
      </div>

      <nav style={{ position: 'sticky', top: 0, zIndex: 1000, background: '#fff', boxShadow: '0 2px 20px rgba(31,78,74,0.08)', borderBottom: '2px solid var(--teal-pale)' }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 72 }}>

          {/* Logo */}
          <Link href="/" style={{ display: 'flex', alignItems: 'center', gap: 12, textDecoration: 'none' }}>
            <div style={{ width: 44, height: 44, background: 'var(--teal)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22 }}>🦷</div>
            <div style={{ lineHeight: 1 }}>
              <div style={{ fontSize: 17, fontWeight: 800, color: 'var(--teal)', letterSpacing: '-0.01em' }}>Smile Dental Clinic</div>
              <div style={{ fontSize: 10, fontWeight: 500, color: 'var(--gold)', letterSpacing: '0.1em', textTransform: 'uppercase', marginTop: 2 }}>Implants · Smile Design · Care</div>
            </div>
          </Link>

          {/* Desktop Nav */}
          <ul style={{ display: 'flex', gap: 4, listStyle: 'none', margin: 0, padding: 0 }} className="desktop-nav">
            <NavItem href="/">Home</NavItem>
            <NavItemDropdown label="Services" href="/services">
              <DropLink href="/services/dental-implants">🦷 Dental Implants</DropLink>
              <DropLink href="/services/smile-designing">✨ Smile Designing</DropLink>
              <DropLink href="/services/dental-scaling">🪥 Dental Scaling</DropLink>
              <DropLink href="/services/pediatric-dentistry">🧒 Pediatric Dentistry</DropLink>
              <DropLink href="/services">🏥 All Services</DropLink>
            </NavItemDropdown>
            <NavItem href="/about">About Us</NavItem>
            <NavItem href="/testimonials">Testimonials</NavItem>
            <NavItem href="/blog">Blog</NavItem>
            <NavItem href="/contact">Contact</NavItem>
          </ul>

          {/* Right actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <a href={`tel:+91${phone}`} style={{ fontSize: 14, fontWeight: 700, color: 'var(--teal)', textDecoration: 'none' }} className="hide-mobile">📞 {phone}</a>
            <Link href="/contact" className="btn btn-gold" style={{ padding: '10px 20px', fontSize: 13 }}>Book Appointment</Link>
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="hamburger"
              aria-label="Menu"
              style={{ display: 'none', flexDirection: 'column', gap: 5, background: 'none', border: 'none', cursor: 'pointer', padding: 8 }}
            >
              {[0,1,2].map(i => <span key={i} style={{ display: 'block', width: 24, height: 2, background: 'var(--teal)', borderRadius: 2 }} />)}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileOpen && (
          <div style={{ background: '#fff', borderTop: '1px solid var(--border)', padding: '16px 24px 24px', display: 'flex', flexDirection: 'column' }}>
            {[
              { href: '/', label: 'Home' },
              { href: '/services', label: 'Services' },
              { href: '/services/dental-implants', label: '↳ Dental Implants' },
              { href: '/services/smile-designing', label: '↳ Smile Designing' },
              { href: '/services/dental-scaling', label: '↳ Dental Scaling' },
              { href: '/services/pediatric-dentistry', label: '↳ Pediatric Dentistry' },
              { href: '/about', label: 'About Us' },
              { href: '/testimonials', label: 'Testimonials' },
              { href: '/blog', label: 'Blog' },
              { href: '/contact', label: 'Contact' },
            ].map(({ href, label }) => (
              <Link key={href} href={href} onClick={() => setMobileOpen(false)}
                style={{ padding: '12px 0', fontSize: 15, color: 'var(--mid)', borderBottom: '1px solid var(--border)', display: 'block', fontWeight: 500 }}>
                {label}
              </Link>
            ))}
            <Link href="/contact" onClick={() => setMobileOpen(false)}
              style={{ marginTop: 14, textAlign: 'center', background: 'var(--teal)', color: '#fff', padding: 14, borderRadius: 8, fontWeight: 700, fontSize: 14 }}>
              📅 Book Appointment
            </Link>
          </div>
        )}
      </nav>

      <style>{`
        @media (max-width: 768px) {
          .desktop-nav { display: none !important; }
          .hide-mobile { display: none !important; }
          .hamburger { display: flex !important; }
        }
        .nav-item-link { font-size: 13.5px; font-weight: 600; color: var(--mid); padding: 8px 14px; border-radius: 8px; display: block; transition: all 0.2s; text-decoration: none; white-space: nowrap; cursor: pointer; }
        .nav-item-link:hover { color: var(--teal); background: var(--teal-pale); }
        .dropdown-wrap { position: relative; }
        .dropdown-menu { display: none; position: absolute; top: calc(100% + 8px); left: 50%; transform: translateX(-50%); background: #fff; border-radius: 12px; box-shadow: 0 16px 48px rgba(0,0,0,0.16); border: 1px solid var(--border); min-width: 220px; z-index: 2000; padding: 8px; }
        .dropdown-wrap:hover .dropdown-menu { display: block; }
        .drop-link { display: flex; align-items: center; gap: 10px; padding: 10px 12px; border-radius: 8px; font-size: 13px; font-weight: 600; color: var(--mid); transition: all 0.15s; text-decoration: none; }
        .drop-link:hover { background: var(--teal-pale); color: var(--teal); }
      `}</style>
    </>
  )
}

function NavItem({ href, children }) {
  return (
    <li>
      <Link href={href} className="nav-item-link">{children}</Link>
    </li>
  )
}

function NavItemDropdown({ label, href, children }) {
  return (
    <li className="dropdown-wrap">
      <Link href={href} className="nav-item-link">{label} <span style={{ fontSize: 10, opacity: 0.6 }}>▾</span></Link>
      <div className="dropdown-menu">{children}</div>
    </li>
  )
}

function DropLink({ href, children }) {
  return <Link href={href} className="drop-link">{children}</Link>
}
