import { defineConfig } from 'sanity'
import { structureTool } from 'sanity/structure'
import { visionTool } from '@sanity/vision'
import { schemaTypes } from './sanity/schemas'

export default defineConfig({
  name: 'smile-dental-clinic',
  title: 'Smile Dental Clinic — CMS',

  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID || 'your_project_id',
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET || 'production',

  plugins: [
    structureTool({
      structure: (S) =>
        S.list()
          .title('Smile Dental Clinic')
          .items([
            // Singleton: Clinic Info
            S.listItem()
              .title('🏥 Clinic Information')
              .child(
                S.document()
                  .schemaType('clinicInfo')
                  .documentId('clinicInfo')
              ),
            S.divider(),
            // Main content
            S.listItem().title('📝 Blog Posts').child(S.documentTypeList('post').title('Blog Posts')),
            S.listItem().title('🦷 Services').child(S.documentTypeList('service').title('Services')),
            S.listItem().title('⭐ Testimonials').child(S.documentTypeList('testimonial').title('Testimonials')),
            S.listItem().title('👨‍⚕️ Doctors & Team').child(S.documentTypeList('doctor').title('Doctors')),
            S.divider(),
            S.listItem().title('❓ FAQs').child(S.documentTypeList('faq').title('FAQs')),
            S.listItem().title('📊 Stats & Numbers').child(S.documentTypeList('stat').title('Stats')),
          ]),
    }),
    visionTool(),
  ],

  schema: {
    types: schemaTypes,
  },
})
