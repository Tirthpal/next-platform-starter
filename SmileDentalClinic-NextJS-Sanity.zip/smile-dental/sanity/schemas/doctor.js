export default {
  name: 'doctor',
  title: 'Doctor / Team Member',
  type: 'document',
  icon: () => '👨‍⚕️',
  fields: [
    { name: 'name', title: 'Full Name', type: 'string', validation: Rule => Rule.required() },
    { name: 'designation', title: 'Designation', type: 'string', description: 'e.g. Dental Implantologist & Smile Design Specialist' },
    { name: 'qualifications', title: 'Qualifications', type: 'string', description: 'e.g. BDS, MDS' },
    { name: 'bio', title: 'Biography', type: 'text', rows: 5 },
    { name: 'order', title: 'Display Order', type: 'number', initialValue: 99 },
    { name: 'image', title: 'Photo', type: 'image',
      options: { hotspot: true },
      fields: [{ name: 'alt', type: 'string', title: 'Alt Text' }]
    },
    { name: 'specializations', title: 'Specializations', type: 'array', of: [{ type: 'string' }] },
    { name: 'experience', title: 'Years of Experience', type: 'number' },
  ],
  preview: { select: { title: 'name', subtitle: 'designation', media: 'image' } },
}
