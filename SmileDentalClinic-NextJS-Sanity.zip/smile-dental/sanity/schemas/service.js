export default {
  name: 'service',
  title: 'Service / Treatment',
  type: 'document',
  icon: () => '🦷',
  fields: [
    { name: 'title', title: 'Service Name', type: 'string', validation: Rule => Rule.required() },
    { name: 'slug', title: 'Slug (URL)', type: 'slug', options: { source: 'title' }, validation: Rule => Rule.required() },
    { name: 'icon', title: 'Emoji Icon', type: 'string', description: 'e.g. 🦷 ✨ 🪥 🧒' },
    { name: 'order', title: 'Display Order', type: 'number', initialValue: 99 },
    { name: 'featured', title: 'Show on Homepage', type: 'boolean', initialValue: false },
    { name: 'shortDescription', title: 'Short Description (Card)', type: 'text', rows: 2, validation: Rule => Rule.required().max(160) },
    { name: 'fullDescription', title: 'Full Description', type: 'array', of: [{ type: 'block' }] },
    { name: 'image', title: 'Main Image', type: 'image', options: { hotspot: true }, fields: [{ name: 'alt', type: 'string', title: 'Alt Text' }] },
    {
      name: 'benefits', title: 'Benefits / Why Choose', type: 'array',
      of: [{
        type: 'object',
        fields: [
          { name: 'icon', title: 'Emoji', type: 'string' },
          { name: 'title', title: 'Title', type: 'string' },
          { name: 'description', title: 'Description', type: 'text' },
        ],
        preview: { select: { title: 'title', subtitle: 'icon' } }
      }]
    },
    {
      name: 'process', title: 'Treatment Process Steps', type: 'array',
      of: [{
        type: 'object',
        fields: [
          { name: 'step', title: 'Step Number', type: 'number' },
          { name: 'title', title: 'Step Title', type: 'string' },
          { name: 'description', title: 'Step Description', type: 'text' },
        ],
        preview: { select: { title: 'title', subtitle: 'step' } }
      }]
    },
    {
      name: 'faq', title: 'FAQs for this Service', type: 'array',
      of: [{
        type: 'object',
        fields: [
          { name: 'question', title: 'Question', type: 'string' },
          { name: 'answer', title: 'Answer', type: 'text' },
        ],
        preview: { select: { title: 'question' } }
      }]
    },
    {
      name: 'pricing', title: 'Pricing Tiers', type: 'array',
      of: [{
        type: 'object',
        fields: [
          { name: 'label', title: 'Plan Label', type: 'string' },
          { name: 'price', title: 'Price (e.g. ₹35,000)', type: 'string' },
          { name: 'description', title: 'Description', type: 'string' },
          { name: 'features', title: 'Features', type: 'array', of: [{ type: 'string' }] },
          { name: 'featured', title: 'Highlight This Plan', type: 'boolean', initialValue: false },
        ],
        preview: { select: { title: 'label', subtitle: 'price' } }
      }]
    },
    { name: 'metaTitle', title: 'SEO Meta Title', type: 'string', group: 'seo' },
    { name: 'metaDescription', title: 'SEO Meta Description', type: 'text', group: 'seo' },
  ],
  groups: [{ name: 'seo', title: 'SEO' }],
  preview: { select: { title: 'title', subtitle: 'shortDescription', media: 'image' } },
  orderings: [{ title: 'Display Order', name: 'orderAsc', by: [{ field: 'order', direction: 'asc' }] }],
}
