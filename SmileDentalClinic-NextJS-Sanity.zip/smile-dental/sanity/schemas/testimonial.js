export default {
  name: 'testimonial',
  title: 'Patient Testimonial',
  type: 'document',
  icon: () => '⭐',
  fields: [
    { name: 'patientName', title: 'Patient Name', type: 'string', validation: Rule => Rule.required() },
    { name: 'service', title: 'Service Received', type: 'string',
      options: { list: [
        'Dental Implants', 'Smile Designing', 'Scaling & Bleaching',
        'Pediatric Dentistry', 'Root Canal', 'Orthodontics',
        'Crowns & Bridges', 'Teeth Whitening', 'Emergency Care', 'General Checkup'
      ]}
    },
    { name: 'rating', title: 'Rating (1-5)', type: 'number',
      validation: Rule => Rule.required().min(1).max(5)
    },
    { name: 'review', title: 'Review Text', type: 'text', rows: 4, validation: Rule => Rule.required() },
    { name: 'featured', title: 'Feature on Homepage', type: 'boolean', initialValue: false },
    { name: 'order', title: 'Display Order', type: 'number', initialValue: 99 },
    { name: 'patientImage', title: 'Patient Photo (Optional)', type: 'image',
      options: { hotspot: true },
      fields: [{ name: 'alt', type: 'string', title: 'Alt Text' }]
    },
    { name: 'location', title: 'Patient Location (e.g. Sector 17, Chandigarh)', type: 'string' },
    { name: 'date', title: 'Review Date', type: 'date' },
  ],
  preview: {
    select: { title: 'patientName', subtitle: 'service', media: 'patientImage' },
    prepare({ title, subtitle }) {
      return { title, subtitle: `⭐ ${subtitle || 'General'}` }
    }
  },
  orderings: [{ title: 'Display Order', name: 'orderAsc', by: [{ field: 'order', direction: 'asc' }] }],
}
