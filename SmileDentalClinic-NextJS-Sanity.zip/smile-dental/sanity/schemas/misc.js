export const faqSchema = {
  name: 'faq',
  title: 'FAQ',
  type: 'document',
  icon: () => '❓',
  fields: [
    { name: 'question', title: 'Question', type: 'string', validation: Rule => Rule.required() },
    { name: 'answer', title: 'Answer', type: 'text', rows: 4, validation: Rule => Rule.required() },
    {
      name: 'category', title: 'Category', type: 'string',
      options: { list: [
        { title: 'Dental Implants', value: 'implants' },
        { title: 'Smile Designing', value: 'smile' },
        { title: 'General', value: 'general' },
        { title: 'Scaling', value: 'scaling' },
        { title: 'Pediatric', value: 'pediatric' },
        { title: 'Pricing & Insurance', value: 'pricing' },
      ]}
    },
    { name: 'order', title: 'Display Order', type: 'number', initialValue: 99 },
  ],
  preview: { select: { title: 'question', subtitle: 'category' } },
  orderings: [{ title: 'Display Order', name: 'orderAsc', by: [{ field: 'order', direction: 'asc' }] }],
}

export const statSchema = {
  name: 'stat',
  title: 'Clinic Stats / Numbers',
  type: 'document',
  icon: () => '📊',
  fields: [
    { name: 'label', title: 'Label', type: 'string', description: 'e.g. Happy Patients', validation: Rule => Rule.required() },
    { name: 'value', title: 'Value', type: 'string', description: 'e.g. 2,000+ or 4.9★', validation: Rule => Rule.required() },
    { name: 'icon', title: 'Emoji Icon', type: 'string' },
    { name: 'order', title: 'Display Order', type: 'number', initialValue: 99 },
  ],
  preview: { select: { title: 'label', subtitle: 'value' } },
}
