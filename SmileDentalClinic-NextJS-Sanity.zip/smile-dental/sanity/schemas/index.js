import post from './post'
import service from './service'
import testimonial from './testimonial'
import doctor from './doctor'
import clinicInfo from './clinicInfo'
import { faqSchema, statSchema } from './misc'

export const schemaTypes = [
  // Singletons
  clinicInfo,
  // Main content
  post,
  service,
  testimonial,
  doctor,
  faqSchema,
  statSchema,
]
