export default {
  name: 'clinicInfo',
  title: 'Clinic Information',
  type: 'document',
  icon: () => '🏥',
  // Singleton — only one document of this type
  __experimental_actions: ['update', 'publish'],
  fields: [
    { name: 'clinicName', title: 'Clinic Name', type: 'string', initialValue: 'Smile Dental Clinic' },
    { name: 'tagline', title: 'Tagline', type: 'string', initialValue: 'Implants · Smile Design · Care' },
    { name: 'phone', title: 'Main Phone', type: 'string', initialValue: '8288929143' },
    { name: 'emergencyPhone', title: 'Emergency Phone', type: 'string' },
    { name: 'email', title: 'Email', type: 'string' },
    { name: 'whatsappNumber', title: 'WhatsApp Number (with country code)', type: 'string', initialValue: '918288929143' },
    { name: 'address', title: 'Full Address', type: 'text', rows: 3 },
    { name: 'city', title: 'City', type: 'string', initialValue: 'Chandigarh' },
    { name: 'mapUrl', title: 'Google Maps URL', type: 'url' },
    { name: 'instagramHandle', title: 'Instagram Handle', type: 'string', initialValue: 'denthealth_38' },
    { name: 'websiteUrl', title: 'Website URL', type: 'url' },
    {
      name: 'openingHours', title: 'Opening Hours', type: 'array',
      of: [{
        type: 'object',
        fields: [
          { name: 'day', title: 'Day(s)', type: 'string' },
          { name: 'hours', title: 'Hours', type: 'string' },
          { name: 'closed', title: 'Closed?', type: 'boolean', initialValue: false },
        ],
        preview: { select: { title: 'day', subtitle: 'hours' } }
      }]
    },
    { name: 'heroHeading', title: 'Hero Heading', type: 'string', group: 'content' },
    { name: 'heroSubheading', title: 'Hero Subheading', type: 'text', group: 'content' },
    { name: 'aboutTitle', title: 'About Section Title', type: 'string', group: 'content' },
    { name: 'aboutDescription', title: 'About Description', type: 'text', group: 'content' },
    { name: 'seoTitle', title: 'SEO Title', type: 'string', group: 'seo' },
    { name: 'seoDescription', title: 'SEO Description', type: 'text', group: 'seo' },
    { name: 'announcementBar', title: 'Announcement Bar Text', type: 'string', group: 'content' },
  ],
  groups: [
    { name: 'content', title: 'Content' },
    { name: 'seo', title: 'SEO' },
  ],
  preview: { prepare() { return { title: 'Clinic Information' } } },
}
