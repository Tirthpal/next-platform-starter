# Smile Dental Clinic — Next.js + Sanity CMS

Full-stack dental clinic website for **Dr. Sumeet Gupta, Smile Dental Clinic, Chandigarh**.

## Tech Stack
- **Frontend**: Next.js 14 (App Router, Server Components)
- **CMS**: Sanity v3 (Studio at `/studio`)
- **Styling**: Custom CSS with teal/gold theme
- **Hosting**: Vercel (recommended)

---

## 🚀 Setup in 5 Steps

### Step 1 — Install Dependencies
```bash
npm install
```

### Step 2 — Create a Sanity Project
1. Go to [sanity.io](https://sanity.io) → Sign up / Log in
2. Click **"New Project"** → name it `smile-dental-clinic`
3. Copy your **Project ID** from the dashboard

### Step 3 — Set Environment Variables
```bash
cp .env.example .env.local
```
Open `.env.local` and fill in:
```
NEXT_PUBLIC_SANITY_PROJECT_ID=your_actual_project_id
NEXT_PUBLIC_SANITY_DATASET=production
NEXT_PUBLIC_SANITY_API_VERSION=2024-01-01
SANITY_API_TOKEN=your_api_token_here
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

To get a `SANITY_API_TOKEN`:
- Go to sanity.io/manage → your project → **API** → **Tokens** → **Add API token**
- Give it **Editor** permissions → copy the token

### Step 4 — Run the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) — your website is live!

### Step 5 — Access the CMS Studio
Go to [http://localhost:3000/studio](http://localhost:3000/studio)

You'll see the Sanity Studio where you can manage:
- 📝 **Blog Posts** — write articles, add images, set categories
- 🦷 **Services** — add/edit all dental services with full details
- ⭐ **Testimonials** — manage patient reviews
- 👨‍⚕️ **Doctors & Team** — add doctor profiles
- 🏥 **Clinic Information** — update phone, address, hours, hero text
- ❓ **FAQs** — manage FAQs by category
- 📊 **Stats** — update the numbers on the homepage

---

## 📁 Project Structure

```
smile-dental/
├── app/
│   ├── (site)/              # All public-facing pages
│   │   ├── layout.js        # Navbar + Footer wrapper
│   │   ├── (home)/page.js   # Homepage
│   │   ├── blog/            # Blog listing + [slug] post pages
│   │   ├── services/        # Services listing + [slug] pages
│   │   ├── about/           # About page
│   │   ├── testimonials/    # Testimonials page
│   │   └── contact/         # Contact + booking form
│   ├── studio/              # Sanity Studio (CMS dashboard)
│   └── api/revalidate/      # Webhook for auto-revalidation
├── components/
│   ├── Navbar.js            # Navigation with dropdown
│   └── Footer.js            # Footer
├── lib/
│   ├── sanity.client.js     # Sanity client config
│   ├── sanity.image.js      # Image URL builder
│   └── sanity.queries.js    # All GROQ queries
├── sanity/
│   └── schemas/             # All content schemas
│       ├── post.js          # Blog posts
│       ├── service.js       # Dental services
│       ├── testimonial.js   # Patient testimonials
│       ├── doctor.js        # Team members
│       ├── clinicInfo.js    # Clinic settings (singleton)
│       ├── misc.js          # FAQs + Stats
│       └── index.js         # Schema registry
├── styles/globals.css       # Global styles
├── sanity.config.js         # Sanity Studio config
└── next.config.js           # Next.js config
```

---

## 🌐 Deploy to Vercel (Free)

1. Push this project to GitHub
2. Go to [vercel.com](https://vercel.com) → **New Project** → import your repo
3. Add all environment variables from `.env.local`
4. Deploy — your site is live!

### Set up Sanity CORS for production:
1. Go to sanity.io/manage → your project → **API** → **CORS Origins**
2. Add your Vercel URL (e.g. `https://your-app.vercel.app`)
3. Allow credentials ✓

### Auto-revalidation webhook (optional but recommended):
1. Go to sanity.io/manage → **API** → **Webhooks** → **Add Webhook**
2. URL: `https://your-site.vercel.app/api/revalidate`
3. Add header: `x-webhook-secret` = any secret string
4. Add the same secret to Vercel env vars as `SANITY_WEBHOOK_SECRET`

---

## 📞 Clinic Details (pre-configured)
| Field | Value |
|---|---|
| Clinic | Smile Dental Clinic |
| Doctor | Dr. Sumeet Gupta |
| Phone | 8288929143 |
| Email | drsumeetdentist@gmail.com |
| Address | SCO 167, Sector 38-C, Chandigarh |
| Instagram | @denthealth_38 |

Update these in **Sanity Studio → Clinic Information**.
