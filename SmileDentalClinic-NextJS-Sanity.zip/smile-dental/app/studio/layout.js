export const metadata = {
  title: 'Smile Dental Clinic — CMS Studio',
}

export default function StudioLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0 }}>{children}</body>
    </html>
  )
}
