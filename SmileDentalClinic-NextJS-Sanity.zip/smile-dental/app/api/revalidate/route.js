import { revalidatePath } from 'next/cache'
import { NextResponse } from 'next/server'

export async function POST(req) {
  const secret = req.headers.get('x-webhook-secret')

  if (secret !== process.env.SANITY_WEBHOOK_SECRET) {
    return NextResponse.json({ message: 'Invalid secret' }, { status: 401 })
  }

  try {
    const body = await req.json()
    const { _type } = body

    // Revalidate relevant paths based on document type
    const pathMap = {
      post: ['/blog', '/'],
      service: ['/services', '/'],
      testimonial: ['/testimonials', '/'],
      doctor: ['/about'],
      clinicInfo: ['/', '/about', '/contact'],
      faq: ['/services'],
      stat: ['/', '/testimonials'],
    }

    const paths = pathMap[_type] || ['/']
    for (const path of paths) {
      revalidatePath(path)
    }

    return NextResponse.json({ revalidated: true, paths })
  } catch (err) {
    return NextResponse.json({ message: 'Revalidation failed', error: err.message }, { status: 500 })
  }
}
