import { Plus_Jakarta_Sans } from 'next/font/google'
import '../styles/globals.css'

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-jakarta',
})

export const metadata = {
  title: { default: 'Smile Dental Clinic — Dr. Sumeet Gupta | Chandigarh', template: '%s | Smile Dental Clinic' },
  description: 'Smile Dental Clinic, Sector 38-C Chandigarh. Dental Implants, Smile Designing, Scaling, Pediatric Dentistry. Dr. Sumeet Gupta — BDS, MDS. Call 8288929143.',
  keywords: ['dental clinic Chandigarh', 'dental implants Chandigarh', 'smile designing', 'Dr Sumeet Gupta', 'pediatric dentistry Chandigarh', 'scaling bleaching'],
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: process.env.NEXT_PUBLIC_SITE_URL,
    siteName: 'Smile Dental Clinic',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={jakarta.variable}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'Dentist',
              name: 'Smile Dental Clinic',
              url: process.env.NEXT_PUBLIC_SITE_URL,
              telephone: '+918288929143',
              email: 'drsumeetdentist@gmail.com',
              address: {
                '@type': 'PostalAddress',
                streetAddress: 'SCO 167, First Floor, Sector 38-C',
                addressLocality: 'Chandigarh',
                postalCode: '160036',
                addressCountry: 'IN',
              },
              openingHoursSpecification: [{
                '@type': 'OpeningHoursSpecification',
                dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
                opens: '09:00', closes: '21:00',
              }],
              aggregateRating: { '@type': 'AggregateRating', ratingValue: '4.9', reviewCount: '59' },
            }),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
