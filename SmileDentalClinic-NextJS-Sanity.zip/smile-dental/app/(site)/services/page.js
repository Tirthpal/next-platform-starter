import Link from 'next/link'
import Image from 'next/image'
import { getAllServices } from '../../../lib/sanity.queries'
import { urlFor } from '../../../lib/sanity.image'

export const revalidate = 60
export const metadata = { title: 'Our Services', description: 'Dental Implants, Smile Designing, Scaling, Pediatric Dentistry and more at Smile Dental Clinic, Sector 38-C Chandigarh.' }

const fallbackServices = [
  { title: 'Dental Implants', slug: { current: 'dental-implants' }, icon: '🦷', shortDescription: 'Permanent, natural-looking tooth replacement. Strong. Natural. Lasting.' },
  { title: 'Smile Designing', slug: { current: 'smile-designing' }, icon: '✨', shortDescription: 'Custom smile makeovers — veneers, whitening, orthodontics designed for you.' },
  { title: 'Dental Scaling', slug: { current: 'dental-scaling' }, icon: '🪥', shortDescription: 'Professional deep cleaning and bleaching for healthier gums and whiter teeth.' },
  { title: 'Pediatric Dentistry', slug: { current: 'pediatric-dentistry' }, icon: '🧒', shortDescription: 'Fun, gentle, stress-free dental care for children from age 1.' },
  { title: 'Root Canal', slug: { current: 'root-canal' }, icon: '🩺', shortDescription: 'Painless, needle-less single-visit root canal treatment.' },
  { title: 'Crowns & Bridges', slug: { current: 'crowns-bridges' }, icon: '👑', shortDescription: 'High-quality crowns and bridges that restore smile, strength and function.' },
  { title: 'Orthodontics', slug: { current: 'orthodontics' }, icon: '😁', shortDescription: 'Braces, Invisalign and clear aligners for every lifestyle.' },
  { title: 'Emergency Dentistry', slug: { current: 'emergency' }, icon: '🚨', shortDescription: '24/7 urgent dental care — same-day appointments always available.' },
]

export default async function ServicesPage() {
  const services = await getAllServices().catch(() => [])
  const displayServices = services.length > 0 ? services : fallbackServices

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span>Services</div>
          <h1>Everything Your Smile <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Needs</em></h1>
          <p>Advanced Care. Beautiful Smiles. Lasting Confidence — Under One Roof at Sector 38-C, Chandigarh.</p>
        </div>
      </div>

      <section className="section section-alt">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 24 }}>
            {displayServices.map((svc) => (
              <Link key={svc._id || svc.title} href={`/services/${svc.slug?.current || svc.title}`}
                style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', border: '1px solid var(--border)', textDecoration: 'none', transition: 'all 0.25s', display: 'flex', flexDirection: 'column' }}
                className="card-hover">
                {svc.image ? (
                  <div style={{ height: 180, overflow: 'hidden', position: 'relative' }}>
                    <Image src={urlFor(svc.image).width(500).height(300).url()} alt={svc.image.alt || svc.title} fill style={{ objectFit: 'cover' }} />
                  </div>
                ) : (
                  <div style={{ height: 120, background: 'var(--teal-pale)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 52, borderBottom: '1px solid var(--teal-pale2)' }}>{svc.icon || '🦷'}</div>
                )}
                <div style={{ padding: 24, flex: 1, display: 'flex', flexDirection: 'column' }}>
                  <h3 style={{ fontSize: 18, fontWeight: 700, color: 'var(--teal)', marginBottom: 8 }}>{svc.title}</h3>
                  <p style={{ fontSize: 13.5, color: 'var(--muted)', lineHeight: 1.7, flex: 1 }}>{svc.shortDescription}</p>
                  <span style={{ marginTop: 16, fontSize: 12, fontWeight: 700, color: 'var(--gold)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>Learn More →</span>
                </div>
              </Link>
            ))}
          </div>
          {services.length === 0 && (
            <p style={{ textAlign: 'center', marginTop: 32, fontSize: 13, color: 'var(--muted)' }}>
              Manage services in the <Link href="/studio" style={{ color: 'var(--teal)', fontWeight: 600 }}>CMS Studio →</Link>
            </p>
          )}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta-banner">
            <div><h2>Not Sure Which Treatment <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>You Need?</em></h2><p>Book a free consultation. Dr. Sumeet will assess, advise, and give you a complete plan — no obligation.</p></div>
            <div className="cta-btns">
              <Link href="/contact" className="btn btn-white">📅 Free Consultation</Link>
              <a href="tel:+918288929143" className="btn btn-outline-white">📞 Call Now</a>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
