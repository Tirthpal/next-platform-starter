import Link from 'next/link'
import Image from 'next/image'
import { PortableText } from '@portabletext/react'
import { getServiceBySlug, getAllServices } from '../../../../lib/sanity.queries'
import { urlFor } from '../../../../lib/sanity.image'
import { notFound } from 'next/navigation'

export const revalidate = 60

export async function generateStaticParams() {
  const services = await getAllServices().catch(() => [])
  return services.map(s => ({ slug: s.slug.current }))
}

export async function generateMetadata({ params }) {
  const svc = await getServiceBySlug(params.slug).catch(() => null)
  if (!svc) return {}
  return {
    title: svc.metaTitle || svc.title,
    description: svc.metaDescription || svc.shortDescription,
  }
}

export default async function ServicePage({ params }) {
  const svc = await getServiceBySlug(params.slug).catch(() => null)

  // If not in Sanity yet, show placeholder
  if (!svc) {
    return (
      <>
        <div className="page-hero">
          <div className="page-hero-inner">
            <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span><Link href="/services">Services</Link><span className="sep">›</span>{params.slug.replace(/-/g, ' ')}</div>
            <h1 style={{ textTransform: 'capitalize' }}>{params.slug.replace(/-/g, ' ')}</h1>
            <p>Full details coming soon. Book a free consultation to learn more.</p>
            <div style={{ display: 'flex', gap: 12, marginTop: 24 }}>
              <Link href="/contact" className="btn btn-white">📅 Book Free Consultation</Link>
              <a href="tel:+918288929143" className="btn btn-outline-white">📞 8288 929 143</a>
            </div>
          </div>
        </div>
        <div style={{ textAlign: 'center', padding: '80px 24px', color: 'var(--muted)' }}>
          <p style={{ fontSize: 14 }}>Add this service in the <Link href="/studio" style={{ color: 'var(--teal)', fontWeight: 600 }}>CMS Studio →</Link></p>
        </div>
      </>
    )
  }

  return (
    <>
      {/* Hero */}
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb">
            <Link href="/">Home</Link><span className="sep">›</span>
            <Link href="/services">Services</Link><span className="sep">›</span>
            {svc.title}
          </div>
          <h1>{svc.icon} <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>{svc.title}</em> — Chandigarh</h1>
          <p>{svc.shortDescription}</p>
          <div style={{ display: 'flex', gap: 12, marginTop: 24, flexWrap: 'wrap' }}>
            <Link href="/contact" className="btn btn-white">📅 Book Free Consultation</Link>
            <a href="tel:+918288929143" className="btn btn-outline-white">📞 8288 929 143</a>
          </div>
        </div>
      </div>

      {/* Main Image */}
      {svc.image && (
        <div style={{ maxWidth: 1100, margin: '0 auto', padding: '48px 24px 0' }}>
          <Image src={urlFor(svc.image).width(1100).height(550).url()} alt={svc.image.alt || svc.title} width={1100} height={550} style={{ borderRadius: 16, width: '100%', height: 'auto', boxShadow: 'var(--shadow-md)' }} />
        </div>
      )}

      {/* Full Description */}
      {svc.fullDescription && (
        <section className="section">
          <div style={{ maxWidth: 760, margin: '0 auto', padding: '0 24px' }}>
            <PortableText value={svc.fullDescription} />
          </div>
        </section>
      )}

      {/* Benefits */}
      {svc.benefits?.length > 0 && (
        <section className="section section-alt">
          <div className="container">
            <div className="section-head">
              <div className="eyebrow">Why Choose This Treatment</div>
              <h2>Benefits of {svc.title}</h2>
              <div className="gold-line" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 20 }}>
              {svc.benefits.map((b, i) => (
                <div key={i} style={{ background: '#fff', borderRadius: 12, padding: 26, border: '1px solid var(--border)', borderTop: '3px solid var(--teal)' }}>
                  <div style={{ fontSize: 26, marginBottom: 12 }}>{b.icon}</div>
                  <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 7, color: 'var(--teal)' }}>{b.title}</h4>
                  <p style={{ fontSize: 13, color: 'var(--mid)', lineHeight: 1.75 }}>{b.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Process */}
      {svc.process?.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="section-head">
              <div className="eyebrow">The Process</div>
              <h2>Step-by-Step Treatment Process</h2>
              <div className="gold-line" />
            </div>
            <div style={{ maxWidth: 760, margin: '0 auto' }}>
              {svc.process.sort((a, b) => a.step - b.step).map((step, i) => (
                <div key={i} style={{ display: 'flex', gap: 20, alignItems: 'flex-start', padding: '20px 0', borderBottom: i < svc.process.length - 1 ? '1px solid var(--border)' : 'none' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 8, background: 'var(--teal)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{step.step}</div>
                  <div>
                    <h4 style={{ fontSize: 16, fontWeight: 700, marginBottom: 6 }}>{step.title}</h4>
                    <p style={{ fontSize: 14, color: 'var(--mid)', lineHeight: 1.7 }}>{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Pricing */}
      {svc.pricing?.length > 0 && (
        <section className="section section-alt">
          <div className="container">
            <div className="section-head">
              <div className="eyebrow">Pricing</div>
              <h2>Transparent Pricing — No Surprises</h2>
              <div className="gold-line" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 20, maxWidth: 900, margin: '0 auto' }}>
              {svc.pricing.map((plan, i) => (
                <div key={i} style={{ background: plan.featured ? 'var(--teal-dark)' : '#fff', borderRadius: 14, padding: 28, border: `1px solid ${plan.featured ? 'var(--teal-dark)' : 'var(--border)'}`, textAlign: 'center' }}>
                  <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: plan.featured ? 'var(--gold-light)' : 'var(--teal)', display: 'block', marginBottom: 10 }}>{plan.label}</span>
                  <div style={{ fontSize: 36, fontWeight: 800, color: plan.featured ? 'var(--gold-light)' : 'var(--charcoal)', lineHeight: 1, marginBottom: 6, letterSpacing: '-0.02em' }}>{plan.price}</div>
                  <p style={{ fontSize: 13, color: plan.featured ? 'rgba(255,255,255,0.65)' : 'var(--muted)', marginBottom: 18 }}>{plan.description}</p>
                  {plan.features?.length > 0 && (
                    <ul style={{ listStyle: 'none', textAlign: 'left', marginBottom: 20 }}>
                      {plan.features.map((f, j) => (
                        <li key={j} style={{ fontSize: 13, color: plan.featured ? 'rgba(255,255,255,0.75)' : 'var(--mid)', padding: '7px 0', borderBottom: `1px solid ${plan.featured ? 'rgba(255,255,255,0.1)' : 'var(--border)'}`, display: 'flex', alignItems: 'center', gap: 8 }}>
                          <span style={{ color: plan.featured ? 'var(--gold-light)' : 'var(--teal)', fontWeight: 700 }}>✓</span>{f}
                        </li>
                      ))}
                    </ul>
                  )}
                  <Link href="/contact" className={`btn ${plan.featured ? 'btn-gold' : 'btn-teal'}`} style={{ width: '100%', justifyContent: 'center' }}>Book Now</Link>
                </div>
              ))}
            </div>
            <p style={{ textAlign: 'center', fontSize: 13, color: 'var(--muted)', marginTop: 20 }}>Prices are indicative. Exact cost provided after free consultation. EMI available.</p>
          </div>
        </section>
      )}

      {/* FAQ */}
      {svc.faq?.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="section-head">
              <div className="eyebrow">FAQ</div>
              <h2>Common Questions Answered</h2>
              <div className="gold-line" />
            </div>
            <div style={{ maxWidth: 740, margin: '0 auto' }}>
              {svc.faq.map((item, i) => (
                <details key={i} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, marginBottom: 10, overflow: 'hidden' }}>
                  <summary style={{ padding: '18px 22px', fontSize: 15, fontWeight: 600, cursor: 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    {item.question}
                  </summary>
                  <div style={{ padding: '0 22px 18px', fontSize: 14, color: 'var(--mid)', lineHeight: 1.8 }}>{item.answer}</div>
                </details>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA */}
      <section className="section section-alt">
        <div className="container">
          <div className="cta-banner">
            <div>
              <h2>Ready for Your <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>{svc.title}?</em></h2>
              <p>Book a free consultation today — no obligation, no pressure.</p>
            </div>
            <div className="cta-btns">
              <Link href="/contact" className="btn btn-white">📅 Book Free Consult</Link>
              <a href="tel:+918288929143" className="btn btn-outline-white">📞 Call Now</a>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
