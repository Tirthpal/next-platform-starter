import Link from 'next/link'
import Image from 'next/image'
import { PortableText } from '@portabletext/react'
import { getPostBySlug, getAllPosts } from '../../../../lib/sanity.queries'
import { urlFor } from '../../../../lib/sanity.image'
import { notFound } from 'next/navigation'

export const revalidate = 60

export async function generateStaticParams() {
  const posts = await getAllPosts().catch(() => [])
  return posts.map(post => ({ slug: post.slug.current }))
}

export async function generateMetadata({ params }) {
  const post = await getPostBySlug(params.slug).catch(() => null)
  if (!post) return {}
  return {
    title: post.metaTitle || post.title,
    description: post.metaDescription || post.excerpt,
    openGraph: {
      title: post.title,
      description: post.excerpt,
      images: post.mainImage ? [{ url: urlFor(post.mainImage).width(1200).height(630).url() }] : [],
    },
  }
}

const portableComponents = {
  types: {
    image: ({ value }) => (
      <div style={{ margin: '24px 0' }}>
        <Image src={urlFor(value).width(800).height(500).url()} alt={value.alt || ''} width={800} height={500} style={{ borderRadius: 12, width: '100%', height: 'auto' }} />
      </div>
    ),
  },
  block: {
    h2: ({ children }) => <h2 style={{ fontSize: 26, fontWeight: 700, margin: '36px 0 14px', letterSpacing: '-0.01em' }}>{children}</h2>,
    h3: ({ children }) => <h3 style={{ fontSize: 20, fontWeight: 700, margin: '28px 0 10px' }}>{children}</h3>,
    normal: ({ children }) => <p style={{ fontSize: 16, color: 'var(--mid)', marginBottom: 18, lineHeight: 1.9 }}>{children}</p>,
    blockquote: ({ children }) => <blockquote style={{ borderLeft: '4px solid var(--teal)', paddingLeft: 20, margin: '24px 0', color: 'var(--mid)', fontStyle: 'italic', fontSize: 16 }}>{children}</blockquote>,
  },
  marks: {
    strong: ({ children }) => <strong style={{ fontWeight: 700, color: 'var(--charcoal)' }}>{children}</strong>,
    link: ({ value, children }) => <a href={value?.href} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--teal)', fontWeight: 600 }}>{children}</a>,
  },
  list: {
    bullet: ({ children }) => <ul style={{ paddingLeft: 24, marginBottom: 18 }}>{children}</ul>,
    number: ({ children }) => <ol style={{ paddingLeft: 24, marginBottom: 18 }}>{children}</ol>,
  },
  listItem: {
    bullet: ({ children }) => <li style={{ fontSize: 15, color: 'var(--mid)', marginBottom: 8, lineHeight: 1.7 }}>{children}</li>,
    number: ({ children }) => <li style={{ fontSize: 15, color: 'var(--mid)', marginBottom: 8, lineHeight: 1.7 }}>{children}</li>,
  },
}

export default async function BlogPostPage({ params }) {
  const post = await getPostBySlug(params.slug).catch(() => null)
  if (!post) notFound()

  return (
    <>
      {/* Hero */}
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb">
            <Link href="/">Home</Link><span className="sep">›</span>
            <Link href="/blog">Blog</Link><span className="sep">›</span>
            <span style={{ color: 'rgba(255,255,255,0.6)' }}>{post.title}</span>
          </div>
          <div style={{ display: 'inline-block', fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--gold)', background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.3)', borderRadius: 4, padding: '4px 10px', marginBottom: 14 }}>
            {post.category?.replace(/-/g, ' ')}
          </div>
          <h1 style={{ fontSize: 'clamp(26px,3.5vw,46px)', color: '#fff', marginBottom: 14, letterSpacing: '-0.025em', maxWidth: 720 }}>{post.title}</h1>
          <p style={{ fontSize: 16, color: 'rgba(255,255,255,0.65)', marginBottom: 16 }}>{post.excerpt}</p>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20, fontSize: 13, color: 'rgba(255,255,255,0.5)' }}>
            {post.author && <span>By <strong style={{ color: 'rgba(255,255,255,0.8)' }}>{post.author.name}</strong></span>}
            {post.publishedAt && <span>{new Date(post.publishedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span>}
          </div>
        </div>
      </div>

      {/* Main Image */}
      {post.mainImage && (
        <div style={{ maxWidth: 900, margin: '0 auto', padding: '0 24px', transform: 'translateY(-32px)' }}>
          <Image src={urlFor(post.mainImage).width(900).height(500).url()} alt={post.mainImage.alt || post.title} width={900} height={500} style={{ borderRadius: 16, width: '100%', height: 'auto', boxShadow: 'var(--shadow-md)' }} />
        </div>
      )}

      {/* Article Body */}
      <div style={{ maxWidth: 760, margin: '0 auto', padding: '0 24px 80px' }}>
        {post.body && <PortableText value={post.body} components={portableComponents} />}

        {/* CTA */}
        <div style={{ marginTop: 48, background: 'var(--teal-pale)', borderRadius: 16, padding: 32, textAlign: 'center', border: '1px solid var(--teal-pale2)' }}>
          <h3 style={{ fontSize: 22, marginBottom: 10 }}>Ready to take action?</h3>
          <p style={{ color: 'var(--mid)', marginBottom: 20 }}>Book a free consultation with Dr. Sumeet Gupta today.</p>
          <Link href="/contact" className="btn btn-teal">📅 Book Free Consultation</Link>
        </div>

        <div style={{ marginTop: 32, textAlign: 'center' }}>
          <Link href="/blog" style={{ color: 'var(--teal)', fontWeight: 600, fontSize: 14 }}>← Back to Blog</Link>
        </div>
      </div>
    </>
  )
}
