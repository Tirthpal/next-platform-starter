import Link from 'next/link'
import Image from 'next/image'
import { getAllPosts } from '../../../lib/sanity.queries'
import { urlFor } from '../../../lib/sanity.image'

export const revalidate = 60
export const metadata = { title: 'Dental Blog — Tips & Insights', description: 'Expert dental advice, oral health tips and patient guides from Dr. Sumeet Gupta at Smile Dental Clinic, Chandigarh.' }

export default async function BlogPage() {
  const posts = await getAllPosts().catch(() => [])

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span>Blog</div>
          <h1>Dental Knowledge From <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Our Clinic</em></h1>
          <p>Expert advice on oral health, implants, cosmetic dentistry and more — from Dr. Sumeet Gupta's team at Smile Dental Clinic, Chandigarh.</p>
        </div>
      </div>

      <section className="section section-alt">
        <div className="container">
          {posts.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '64px 0', color: 'var(--muted)' }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>📝</div>
              <h3>Blog posts coming soon</h3>
              <p style={{ marginTop: 8, fontSize: 14 }}>Add your first blog post in the <Link href="/studio" style={{ color: 'var(--teal)', fontWeight: 600 }}>CMS Studio →</Link></p>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))', gap: 24 }}>
              {posts.map((post) => (
                <Link key={post._id} href={`/blog/${post.slug.current}`}
                  style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', border: '1px solid var(--border)', textDecoration: 'none', display: 'block', transition: 'all 0.25s' }}
                  className="card-hover">
                  {post.mainImage ? (
                    <div style={{ height: 200, overflow: 'hidden', position: 'relative' }}>
                      <Image src={urlFor(post.mainImage).width(600).height(400).url()} alt={post.mainImage.alt || post.title} fill style={{ objectFit: 'cover' }} />
                    </div>
                  ) : (
                    <div style={{ height: 160, background: 'var(--teal-pale)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 48 }}>🦷</div>
                  )}
                  <div style={{ padding: 24 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                      <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--gold)' }}>{post.category?.replace(/-/g, ' ')}</span>
                      <span style={{ fontSize: 11, color: 'var(--muted)' }}>{new Date(post.publishedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                    </div>
                    <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 8, lineHeight: 1.35 }}>{post.title}</h3>
                    <p style={{ fontSize: 13.5, color: 'var(--muted)', lineHeight: 1.7, marginBottom: 16 }}>{post.excerpt}</p>
                    {post.author && <p style={{ fontSize: 12, color: 'var(--mid)', fontWeight: 600 }}>By {post.author.name}</p>}
                    <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--teal)', letterSpacing: '0.04em', textTransform: 'uppercase', marginTop: 12, display: 'block' }}>Read Article →</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>
    </>
  )
}
