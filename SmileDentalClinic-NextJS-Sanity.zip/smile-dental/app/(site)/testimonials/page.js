import Link from 'next/link'
import { getAllTestimonials, getStats } from '../../../lib/sanity.queries'

export const revalidate = 60
export const metadata = { title: 'Patient Testimonials', description: '59 verified Google reviews for Smile Dental Clinic, Chandigarh. Real patients, real results.' }

export default async function TestimonialsPage() {
  const [testimonials, stats] = await Promise.all([
    getAllTestimonials().catch(() => []),
    getStats().catch(() => []),
  ])

  const displayStats = stats.length > 0 ? stats : [
    { value: '4.9★', label: 'Google Rating', _id: '1' },
    { value: '59', label: 'Verified Reviews', _id: '2' },
    { value: '2,000+', label: 'Patients Treated', _id: '3' },
    { value: '24/7', label: 'Always Available', _id: '4' },
  ]

  const displayTestimonials = testimonials.length > 0 ? testimonials : defaultTestimonials

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span>Testimonials</div>
          <h1>What Our Patients <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Actually Say</em></h1>
          <p>59 verified Google reviews — unfiltered, unedited. Real patients, real results from Chandigarh's most trusted dental clinic.</p>
        </div>
      </div>

      <section className="section section-alt">
        <div className="container">
          {/* Stats Strip */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', background: '#fff', borderRadius: 14, border: '1px solid var(--border)', overflow: 'hidden', marginBottom: 56, boxShadow: 'var(--shadow)' }}>
            {displayStats.map((s, i, arr) => (
              <div key={s._id} style={{ padding: '28px 16px', textAlign: 'center', borderRight: i < arr.length - 1 ? '1px solid var(--border)' : 'none' }}>
                <div style={{ fontSize: 38, fontWeight: 800, color: 'var(--teal)', lineHeight: 1, letterSpacing: '-0.03em' }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginTop: 6 }}>{s.label}</div>
              </div>
            ))}
          </div>

          {/* Testimonials Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 20 }}>
            {displayTestimonials.map((t, i) => (
              <div key={t._id || i} style={{
                background: t.featured ? 'var(--teal-dark)' : '#fff',
                borderRadius: 14, padding: 28,
                border: `1px solid ${t.featured ? 'var(--teal-dark)' : 'var(--border)'}`,
                borderTop: `3px solid ${t.featured ? 'var(--gold)' : 'var(--teal-pale2)'}`,
                transition: 'all 0.2s',
              }}>
                <div style={{ display: 'inline-block', fontSize: 10, fontWeight: 700, letterSpacing: '0.07em', textTransform: 'uppercase', color: t.featured ? 'var(--gold-light)' : 'var(--teal)', background: t.featured ? 'rgba(255,255,255,0.1)' : 'var(--teal-pale)', padding: '3px 10px', borderRadius: 4, marginBottom: 12 }}>
                  {t.service}
                </div>
                <div style={{ display: 'flex', gap: 2, marginBottom: 10 }}>
                  {Array.from({ length: t.rating || 5 }).map((_, j) => <span key={j} style={{ color: 'var(--gold)', fontSize: 15 }}>★</span>)}
                </div>
                <p style={{ fontSize: 14, color: t.featured ? 'rgba(255,255,255,0.82)' : 'var(--mid)', fontStyle: 'italic', lineHeight: 1.8, marginBottom: 18 }}>"{t.review}"</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: t.featured ? 'rgba(255,255,255,0.15)' : 'var(--teal-pale)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>😊</div>
                  <div>
                    <strong style={{ fontSize: 13, fontWeight: 700, display: 'block', color: t.featured ? '#fff' : 'var(--charcoal)' }}>{t.patientName}</strong>
                    <span style={{ fontSize: 11, color: t.featured ? 'rgba(255,255,255,0.5)' : 'var(--muted)' }}>{t.location || 'Chandigarh'}{t.date ? ` · ${new Date(t.date).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}` : ''}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {testimonials.length === 0 && (
            <p style={{ textAlign: 'center', marginTop: 24, fontSize: 13, color: 'var(--muted)' }}>
              Add testimonials in the <Link href="/studio" style={{ color: 'var(--teal)', fontWeight: 600 }}>CMS Studio →</Link>
            </p>
          )}

          <div style={{ textAlign: 'center', marginTop: 40 }}>
            <a href="https://g.page/r/review" target="_blank" rel="noopener" className="btn btn-teal">Read All 59 Google Reviews →</a>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta-banner">
            <div><h2>Join 2,000+ Happy <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Chandigarh Patients</em></h2><p>Book your free consultation today — no pressure, no hidden costs.</p></div>
            <div className="cta-btns">
              <Link href="/contact" className="btn btn-white">📅 Book Now</Link>
              <a href="tel:+918288929143" className="btn btn-outline-white">📞 Call Us</a>
            </div>
          </div>
        </div>
      </section>
    </>
  )
}

const defaultTestimonials = [
  { patientName: 'Priya S.', service: 'Root Canal', rating: 5, featured: true, review: 'The painless RCT was a revelation — I felt absolutely nothing. The team at Smile Dental Sector 38 are magicians. Will never go anywhere else.' },
  { patientName: 'Rahul M.', service: 'Invisalign', rating: 5, review: 'My Invisalign journey took 8 months and the results are jaw-dropping. Staff explained every step clearly and patiently.' },
  { patientName: 'Sunita K.', service: 'Dental Implant', rating: 5, review: 'Got an implant after years of hiding my smile. Now I can\'t stop smiling! Best dental clinic in Chandigarh without a doubt.' },
  { patientName: 'Arjun D.', service: 'Emergency Care', rating: 5, review: 'Emergency at 2AM — they answered, I was seen within the hour. Incredible 24/7 service. Dr. Sumeet is exceptional.' },
  { patientName: 'Meena T.', service: 'Pediatric Dentistry', rating: 5, review: 'Brought my 5-year-old daughter who was terrified. The paediatric team made it fun and easy. She wants to go back!' },
  { patientName: 'Vikram B.', service: 'Teeth Whitening', rating: 5, review: 'Whitening results were beyond expectations — 7 shades lighter in one sitting. Worth every rupee.' },
  { patientName: 'Kavita R.', service: 'Smile Designing', rating: 5, review: 'Dr. Sumeet is incredibly skilled and patient. He explained everything clearly. My smile design turned out perfect.' },
  { patientName: 'Manish P.', service: 'Scaling', rating: 5, review: 'The scaling was so thorough and painless. My gums feel healthier than ever. Will definitely come back every 6 months.' },
  { patientName: 'Sandeep K.', service: 'General Checkup', rating: 5, review: 'Transparent pricing — what they quoted is what I paid. No surprises. That alone makes them stand out in Chandigarh.' },
]
