import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'
import { getClinicInfo } from '../../lib/sanity.queries'

export default async function SiteLayout({ children }) {
  const clinicInfo = await getClinicInfo().catch(() => null)

  return (
    <>
      {/* Floating buttons */}
      <a href={`https://wa.me/${clinicInfo?.whatsappNumber || '918288929143'}`}
        className="float-btn float-whatsapp" target="_blank" rel="noopener" title="Chat on WhatsApp">💬</a>
      <a href={`tel:+91${clinicInfo?.phone || '8288929143'}`}
        className="float-btn float-call" title="Call Now">📞</a>

      <Navbar clinicInfo={clinicInfo} />
      <main>{children}</main>
      <Footer clinicInfo={clinicInfo} />
    </>
  )
}
