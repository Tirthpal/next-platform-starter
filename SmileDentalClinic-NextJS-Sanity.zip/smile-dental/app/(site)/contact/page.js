'use client'

import Link from 'next/link'
import { useState } from 'react'

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ firstName: '', lastName: '', phone: '', email: '', service: '', date: '', time: 'Morning 9–12pm', message: '' })

  function handleSubmit(e) {
    e.preventDefault()
    // In production: send to your API route / Sanity / email service
    setSubmitted(true)
  }

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span>Contact & Booking</div>
          <h1>Let's Get Your <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Appointment Booked</em></h1>
          <p>Fill the form and we'll confirm within 2 hours. Prefer to call? We're available 24/7 — including weekends and holidays.</p>
        </div>
      </div>

      <section className="section section-alt">
        <div className="container">
          {/* Emergency Banner */}
          <div style={{ background: '#C0392B', borderRadius: 12, padding: '22px 28px', display: 'flex', alignItems: 'center', gap: 16, marginBottom: 36, flexWrap: 'wrap' }}>
            <span style={{ fontSize: 28 }}>🚨</span>
            <div>
              <h3 style={{ fontSize: 16, color: '#fff', fontWeight: 700, marginBottom: 3 }}>Dental Emergency?</h3>
              <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)' }}>Severe pain, swelling, or knocked-out tooth — call our 24/7 line immediately.</p>
            </div>
            <a href="tel:+918288929143" style={{ background: '#fff', color: '#C0392B', fontWeight: 700, fontSize: 13, padding: '10px 20px', borderRadius: 6, marginLeft: 'auto', whiteSpace: 'nowrap', textDecoration: 'none' }}>
              Call 8288 929 143
            </a>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 36, alignItems: 'start' }}>
            {/* Info */}
            <div style={{ background: '#fff', borderRadius: 16, padding: 40, border: '1px solid var(--border)', borderTop: '4px solid var(--gold)', boxShadow: 'var(--shadow)' }}>
              <h3 style={{ fontSize: 20, marginBottom: 24 }}>Clinic Information</h3>
              {[
                { icon: '📍', title: 'Address', content: 'SCO 167, First Floor, Community Centre\nMarket Rd, Sector 38-D, Chandigarh 160036\n(Near Medanta Hospital)' },
                { icon: '📞', title: 'Phone', content: '+91 8288 929 143', href: 'tel:+918288929143' },
                { icon: '📧', title: 'Email', content: 'drsumeetdentist@gmail.com', href: 'mailto:drsumeetdentist@gmail.com' },
                { icon: '💬', title: 'WhatsApp', content: 'Chat on WhatsApp →', href: 'https://wa.me/918288929143' },
                { icon: '📷', title: 'Instagram', content: '@denthealth_38', href: 'https://instagram.com/denthealth_38' },
                { icon: '🌐', title: 'Website', content: 'www.smiledentalclinic.in', href: 'https://www.smiledentalclinic.in' },
                { icon: '⏰', title: 'Hours', content: 'Open 24/7 — Including Holidays', green: true },
              ].map((item) => (
                <div key={item.title} style={{ display: 'flex', gap: 14, alignItems: 'flex-start', padding: '14px 0', borderBottom: '1px solid var(--border)' }}>
                  <div style={{ width: 42, height: 42, background: 'var(--teal-pale)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 19, flexShrink: 0, border: '1px solid var(--teal-pale2)' }}>{item.icon}</div>
                  <div>
                    <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: 4 }}>{item.title}</div>
                    {item.href ? (
                      <a href={item.href} style={{ fontSize: 14, color: 'var(--teal)', fontWeight: 600 }}>{item.content}</a>
                    ) : (
                      <p style={{ fontSize: 14, color: item.green ? '#10B981' : 'var(--charcoal)', fontWeight: item.green ? 700 : 400, whiteSpace: 'pre-line', lineHeight: 1.65 }}>{item.content}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Form */}
            <div style={{ background: '#fff', borderRadius: 16, padding: 40, border: '1px solid var(--border)', borderTop: '4px solid var(--teal)', boxShadow: 'var(--shadow)' }}>
              {submitted ? (
                <div style={{ textAlign: 'center', padding: '48px 0' }}>
                  <div style={{ fontSize: 56, marginBottom: 14 }}>🎉</div>
                  <h3 style={{ fontSize: 22, marginBottom: 10 }}>Booking Received!</h3>
                  <p style={{ color: 'var(--muted)', fontSize: 14, lineHeight: 1.8 }}>We'll call within 2 hours to confirm your slot. Check your WhatsApp for updates.</p>
                  <button onClick={() => setSubmitted(false)} className="btn btn-teal" style={{ marginTop: 24 }}>Book Another</button>
                </div>
              ) : (
                <>
                  <h3 style={{ fontSize: 20, marginBottom: 6 }}>Book an Appointment</h3>
                  <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 24 }}>Confirmed within 2 hours via call or WhatsApp.</p>
                  <form onSubmit={handleSubmit}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                      <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', letterSpacing: '0.06em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>First Name *</label>
                        <input required value={form.firstName} onChange={e => setForm(p => ({ ...p, firstName: e.target.value }))} placeholder="Rajat" style={inputStyle} />
                      </div>
                      <div>
                        <label style={{ fontSize: 11, fontWeight: 700, color: 'var(--muted)', letterSpacing: '0.06em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }}>Last Name *</label>
                        <input required value={form.lastName} onChange={e => setForm(p => ({ ...p, lastName: e.target.value }))} placeholder="Sharma" style={inputStyle} />
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                      <div>
                        <label style={labelStyle}>Phone *</label>
                        <input required type="tel" value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} placeholder="8288 929 143" style={inputStyle} />
                      </div>
                      <div>
                        <label style={labelStyle}>Email</label>
                        <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} placeholder="you@example.com" style={inputStyle} />
                      </div>
                    </div>
                    <div style={{ marginBottom: 14 }}>
                      <label style={labelStyle}>Service Required *</label>
                      <select required value={form.service} onChange={e => setForm(p => ({ ...p, service: e.target.value }))} style={inputStyle}>
                        <option value="">Select a service...</option>
                        {['Dental Implants (Free Consult)', 'Smile Designing', 'Dental Scaling & Bleaching', 'Pediatric Dentistry', 'Root Canal', 'Teeth Whitening', 'Orthodontics / Braces', 'Crowns & Bridges', 'Emergency Appointment', 'General Checkup'].map(s => <option key={s}>{s}</option>)}
                      </select>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 14 }}>
                      <div>
                        <label style={labelStyle}>Preferred Date</label>
                        <input type="date" value={form.date} onChange={e => setForm(p => ({ ...p, date: e.target.value }))} style={inputStyle} />
                      </div>
                      <div>
                        <label style={labelStyle}>Preferred Time</label>
                        <select value={form.time} onChange={e => setForm(p => ({ ...p, time: e.target.value }))} style={inputStyle}>
                          <option>Morning 9–12pm</option>
                          <option>Afternoon 12–4pm</option>
                          <option>Evening 4–9pm</option>
                        </select>
                      </div>
                    </div>
                    <div style={{ marginBottom: 16 }}>
                      <label style={labelStyle}>Message</label>
                      <textarea value={form.message} onChange={e => setForm(p => ({ ...p, message: e.target.value }))} placeholder="Any symptoms or questions for Dr. Sumeet..." style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }} />
                    </div>
                    <button type="submit" className="btn btn-teal" style={{ width: '100%', justifyContent: 'center', padding: 15, fontSize: 15 }}>Confirm Appointment →</button>
                    <p style={{ fontSize: 11, color: 'var(--muted)', textAlign: 'center', marginTop: 10 }}>🔒 Your details are private. No spam, ever.</p>
                  </form>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      <style>{`@media(max-width:900px){section>div>div[style*="grid-template-columns: 1fr 1fr"]{grid-template-columns:1fr!important}}`}</style>
    </>
  )
}

const inputStyle = { width: '100%', padding: '12px 16px', border: '1.5px solid var(--border)', borderRadius: 8, fontFamily: 'inherit', fontSize: 14, color: 'var(--charcoal)', background: 'var(--bg)', outline: 'none' }
const labelStyle = { fontSize: 11, fontWeight: 700, color: 'var(--muted)', letterSpacing: '0.06em', textTransform: 'uppercase', display: 'block', marginBottom: 5 }
