import Link from 'next/link'
import Image from 'next/image'
import { getAllDoctors, getClinicInfo } from '../../../lib/sanity.queries'
import { urlFor } from '../../../lib/sanity.image'

export const revalidate = 60
export const metadata = { title: 'About Us — Dr. Sumeet Gupta', description: 'Learn about Smile Dental Clinic, Dr. Sumeet Gupta, and our commitment to excellent dental care in Sector 38-C, Chandigarh.' }

export default async function AboutPage() {
  const [doctors, clinicInfo] = await Promise.all([
    getAllDoctors().catch(() => []),
    getClinicInfo().catch(() => null),
  ])

  return (
    <>
      <div className="page-hero">
        <div className="page-hero-inner">
          <div className="breadcrumb"><Link href="/">Home</Link><span className="sep">›</span>About Us</div>
          <h1>About <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Smile Dental Clinic</em></h1>
          <p>Experienced. Passionate. Committed to Excellence. Dr. Sumeet Gupta and the Smile Dental team are dedicated to providing world-class dental care with a personal touch.</p>
        </div>
      </div>

      {/* Story */}
      <section className="section section-alt">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
            <div style={{ background: 'var(--teal-pale)', borderRadius: 20, height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 80, border: '1px solid var(--teal-pale2)', position: 'relative' }}>
              👨‍⚕️
              <div style={{ position: 'absolute', bottom: 24, right: 24, background: 'var(--teal)', color: '#fff', borderRadius: 12, padding: '16px 20px', textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 800, lineHeight: 1 }}>13+</div>
                <div style={{ fontSize: 11, opacity: 0.8 }}>Years Experience</div>
              </div>
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 14 }}>
                <span style={{ width: 24, height: 1, background: 'var(--gold)', display: 'inline-block' }} />Our Story<span style={{ width: 24, height: 1, background: 'var(--gold)', display: 'inline-block' }} />
              </div>
              <h2 style={{ fontSize: 'clamp(26px,3vw,40px)', marginBottom: 16, letterSpacing: '-0.02em' }}>Built on a Simple <em style={{ fontStyle: 'italic', color: 'var(--teal)' }}>Belief</em></h2>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14, background: 'var(--teal-pale)', borderRadius: 12, padding: '16px 20px', border: '1px solid var(--teal-pale2)', marginBottom: 20 }}>
                <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'var(--teal)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>👨‍⚕️</div>
                <div>
                  <strong style={{ display: 'block', fontSize: 16, fontWeight: 700, color: 'var(--teal)' }}>Dr. Sumeet Gupta</strong>
                  <span style={{ fontSize: 12, color: 'var(--muted)' }}>BDS, MDS — Dental Implantologist & Smile Design Specialist</span>
                </div>
              </div>
              <p style={{ fontSize: 15.5, color: 'var(--mid)', lineHeight: 1.85, marginBottom: 16 }}>
                {clinicInfo?.aboutDescription || 'Smile Dental Clinic was founded by Dr. Sumeet Gupta with one conviction: every patient deserves exceptional dental care delivered with honesty, compassion, and clinical excellence.'}
              </p>
              <p style={{ fontSize: 15.5, color: 'var(--mid)', lineHeight: 1.85, marginBottom: 24 }}>
                With over 13 years of experience and 2,000+ successful treatments, Dr. Gupta has built Chandigarh's most trusted dental practice at Sector 38-C — combining cutting-edge technology with a deeply human approach to care.
              </p>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                {['ISO 9001:2015 Certified', 'IDA Member Clinic', 'Nobel Biocare Partner', 'Invisalign Provider'].map(c => (
                  <span key={c} style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 600 }}>🏅 {c}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div className="eyebrow">What We Stand For</div>
            <h2>Our Values</h2>
            <div className="gold-line" />
            <p style={{ marginTop: 16 }}>Not a marketing statement — these are the principles we actually run the clinic by.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 18 }}>
            {[
              { vi: '🔍', title: 'Radical Transparency', desc: 'We explain every diagnosis and quote every cost before starting. If you don\'t need a treatment, we tell you.' },
              { vi: '🎓', title: 'Clinical Excellence', desc: 'Every doctor holds postgraduate qualifications and attends minimum 40 hours of CPD annually.' },
              { vi: '💬', title: 'Patient-Centred Care', desc: 'Your comfort, preferences, and life circumstances shape every treatment plan — never one-size-fits-all.' },
              { vi: '🛡️', title: 'Safety First', desc: 'ISO-certified sterilisation, single-use instruments for every patient, and regular infection control audits.' },
              { vi: '💡', title: 'Technology-Forward', desc: '3D CBCT imaging, digital impressions, computer-guided implant surgery — we invest in what genuinely improves outcomes.' },
              { vi: '🤝', title: 'Honest Pricing', desc: 'Easy EMI, no hidden costs, written treatment plans before any procedure. The price you\'re told is the price you pay.' },
            ].map(v => (
              <div key={v.title} style={{ background: '#fff', borderRadius: 12, padding: 26, border: '1px solid var(--border)', borderTop: '3px solid var(--gold)' }}>
                <div style={{ fontSize: 26, marginBottom: 12 }}>{v.vi}</div>
                <h4 style={{ fontSize: 15, fontWeight: 700, marginBottom: 7 }}>{v.title}</h4>
                <p style={{ fontSize: 13, color: 'var(--mid)', lineHeight: 1.75 }}>{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Doctors / Team */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <div className="eyebrow">The Team</div>
            <h2>Specialists Who <em style={{ fontStyle: 'italic', color: 'var(--teal)' }}>Genuinely Care</em></h2>
            <div className="gold-line" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(220px,1fr))', gap: 22 }}>
            {(doctors.length > 0 ? doctors : defaultDoctors).map((doc, i) => (
              <div key={doc._id || i} style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', border: '1px solid var(--border)', textAlign: 'center', transition: 'all 0.25s' }} className="card-hover">
                <div style={{ background: 'var(--teal-pale)', padding: '32px 20px 22px', borderBottom: '1px solid var(--teal-pale2)' }}>
                  {doc.image ? (
                    <div style={{ width: 80, height: 80, borderRadius: '50%', overflow: 'hidden', margin: '0 auto 12px', border: '3px solid rgba(255,255,255,0.7)' }}>
                      <Image src={urlFor(doc.image).width(160).height(160).url()} alt={doc.name} width={80} height={80} style={{ objectFit: 'cover' }} />
                    </div>
                  ) : (
                    <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'var(--teal)', margin: '0 auto 12px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, border: '3px solid rgba(255,255,255,0.7)' }}>👨‍⚕️</div>
                  )}
                  <h3 style={{ fontSize: 16, marginBottom: 4 }}>{doc.name}</h3>
                  <div style={{ fontSize: 11, color: 'var(--teal)', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' }}>{doc.designation}</div>
                </div>
                <div style={{ padding: '18px 20px' }}>
                  <p style={{ fontSize: 12.5, color: 'var(--mid)', lineHeight: 1.75, marginBottom: 12 }}>{doc.bio}</p>
                  {doc.qualifications && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5, justifyContent: 'center' }}>
                      {doc.qualifications.split(',').map(q => (
                        <span key={q} style={{ background: 'var(--teal-pale)', color: 'var(--teal)', fontSize: 10, fontWeight: 700, letterSpacing: '0.05em', padding: '3px 8px', borderRadius: 4 }}>{q.trim()}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
          {doctors.length === 0 && (
            <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13, color: 'var(--muted)' }}>
              Add your team in the <Link href="/studio" style={{ color: 'var(--teal)', fontWeight: 600 }}>CMS Studio →</Link>
            </p>
          )}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta-banner">
            <div><h2>Your Smile. Our Passion. <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Your Confidence.</em></h2><p>Book your consultation and experience the Smile Dental difference.</p></div>
            <div className="cta-btns">
              <Link href="/contact" className="btn btn-white">📅 Book Now</Link>
              <a href="tel:+918288929143" className="btn btn-outline-white">📞 Call Now</a>
            </div>
          </div>
        </div>
      </section>

      <style>{`@media(max-width:900px){section>div>div[style*="grid-template-columns: 1fr 1fr"]{grid-template-columns:1fr!important}}`}</style>
    </>
  )
}

const defaultDoctors = [
  { name: 'Dr. Sumeet Gupta', designation: 'Implantologist & Director', qualifications: 'BDS, MDS', bio: '13+ years specialising in complex implant cases and full-arch rehabilitation. Has placed 2,000+ implants in Chandigarh.' },
]
