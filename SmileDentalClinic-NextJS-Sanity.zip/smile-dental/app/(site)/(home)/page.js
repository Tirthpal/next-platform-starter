import Link from 'next/link'
import Image from 'next/image'
import { getAllServices, getFeaturedTestimonials, getFeaturedPosts, getClinicInfo, getStats } from '../../../lib/sanity.queries'
import { urlFor } from '../../../lib/sanity.image'

export const revalidate = 60

export const metadata = {
  title: 'Smile Dental Clinic — Dr. Sumeet Gupta | Chandigarh',
  description: 'Advanced dental care in Sector 38-C Chandigarh. Dental Implants, Smile Designing, Scaling, Pediatric Dentistry. Open 24/7. Call 8288929143.',
}

export default async function HomePage() {
  const [services, testimonials, posts, clinicInfo, stats] = await Promise.all([
    getAllServices().catch(() => []),
    getFeaturedTestimonials().catch(() => []),
    getFeaturedPosts().catch(() => []),
    getClinicInfo().catch(() => null),
    getStats().catch(() => []),
  ])

  const phone = clinicInfo?.phone || '8288929143'
  const whatsapp = clinicInfo?.whatsappNumber || '918288929143'

  return (
    <>
      {/* ── HERO ── */}
      <section style={{ background: 'var(--teal-dark)', padding: '100px 0 72px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(rgba(255,255,255,0.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.025) 1px,transparent 1px)', backgroundSize: '48px 48px' }} />
        <div className="container" style={{ position: 'relative', zIndex: 1, display: 'grid', gridTemplateColumns: '1fr 400px', gap: 56, alignItems: 'center' }}>
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.18)', borderRadius: 100, padding: '7px 16px', marginBottom: 24 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#4DFF91', display: 'inline-block' }} />
              <span style={{ fontSize: 12, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.85)', fontWeight: 600 }}>Now Accepting New Patients</span>
            </div>
            <h1 style={{ fontSize: 'clamp(36px,4.5vw,62px)', color: '#fff', marginBottom: 16, letterSpacing: '-0.025em', lineHeight: 1.1 }}>
              {clinicInfo?.heroHeading || 'Creating Healthy Smiles,'}<br />
              <span style={{ fontStyle: 'italic', color: 'var(--gold-light)', fontWeight: 400 }}>Changing Lives.</span>
            </h1>
            <p style={{ fontSize: 17, color: 'rgba(255,255,255,0.68)', maxWidth: 520, lineHeight: 1.8, marginBottom: 28 }}>
              {clinicInfo?.heroSubheading || 'Advanced Dental Care with Compassion, Precision & Perfection. Open 24/7.'}
            </p>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 36 }}>
              {['Advanced Technology', 'Painless Treatment', 'Safe & Hygienic', 'Care for Whole Family'].map(t => (
                <span key={t} style={{ background: 'rgba(255,255,255,0.1)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 100, padding: '6px 14px', fontSize: 12, color: 'rgba(255,255,255,0.85)', fontWeight: 600 }}>{t}</span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <Link href="/contact" className="btn btn-white">📅 Book Appointment</Link>
              <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noopener" className="btn btn-outline-white">💬 WhatsApp Us</a>
            </div>
          </div>

          {/* Quick Book Card */}
          <div style={{ background: '#fff', borderRadius: 16, padding: 32, boxShadow: '0 20px 56px rgba(0,0,0,0.28)', borderTop: '4px solid var(--gold)' }}>
            <h3 style={{ fontSize: 19, marginBottom: 6 }}>Quick Appointment</h3>
            <p style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 18 }}>Confirmed within 2 hours</p>
            <div style={{ background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 6, padding: '9px 14px', marginBottom: 18, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', background: '#10B981', display: 'inline-block' }} />
              <span style={{ fontSize: 12, color: '#065F46', fontWeight: 700 }}>Slots available today</span>
            </div>
            <QuickForm services={services} phone={phone} />
          </div>
        </div>

        {/* Stats row */}
        <div className="container" style={{ position: 'relative', zIndex: 1, marginTop: 40 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 10, overflow: 'hidden' }}>
            {(stats.length > 0 ? stats : [
              { value: '2,000+', label: 'Happy Patients', icon: '😊' },
              { value: '4.9★', label: 'Google Rating', icon: '⭐' },
              { value: '13+', label: 'Years Experience', icon: '🎓' },
              { value: '24/7', label: 'Always Open', icon: '🚨' },
            ]).map((s, i, arr) => (
              <div key={s._id || i} style={{ padding: '18px 16px', textAlign: 'center', borderRight: i < arr.length - 1 ? '1px solid rgba(255,255,255,0.1)' : 'none' }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.5)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginTop: 4 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── GOLD DIVIDER ── */}
      <div className="gold-divider" />

      {/* ── SERVICES ── */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <div className="eyebrow">What We Offer</div>
            <h2>Services We Provide</h2>
            <div className="gold-line" />
            <p style={{ marginTop: 16 }}>Advanced Care. Beautiful Smiles. Lasting Confidence.</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(200px,1fr))', gap: 16 }}>
            {(services.length > 0 ? services : defaultServices).map((svc) => (
              <Link key={svc._id || svc.title} href={`/services/${svc.slug?.current || svc.slug || '#'}`}
                style={{ background: '#fff', border: '1px solid var(--border)', borderRadius: 14, padding: '28px 20px', textAlign: 'center', textDecoration: 'none', transition: 'all 0.25s', display: 'block', position: 'relative', overflow: 'hidden' }}
                className="card-hover">
                <div style={{ fontSize: 36, marginBottom: 14 }}>{svc.icon || '🦷'}</div>
                <h3 style={{ fontSize: 15, fontWeight: 700, color: 'var(--teal)', marginBottom: 6 }}>{svc.title}</h3>
                <p style={{ fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.6 }}>{svc.shortDescription}</p>
                <div style={{ marginTop: 14, fontSize: 12, color: 'var(--gold)', fontWeight: 700 }}>Learn More →</div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section className="section">
        <div className="container">
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
            <div style={{ background: 'var(--teal-pale)', borderRadius: 20, height: 480, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 80, border: '1px solid var(--teal-pale2)', position: 'relative' }}>
              👨‍⚕️
              <div style={{ position: 'absolute', bottom: 24, right: 24, background: 'var(--teal)', color: '#fff', borderRadius: 12, padding: '16px 20px', textAlign: 'center' }}>
                <div style={{ fontSize: 28, fontWeight: 800, lineHeight: 1 }}>13+</div>
                <div style={{ fontSize: 11, opacity: 0.8, fontWeight: 500 }}>Years Experience</div>
              </div>
            </div>
            <div>
              <div className="eyebrow" style={{ justifyContent: 'flex-start' }}>About Us</div>
              <h2 style={{ fontSize: 'clamp(26px,3vw,40px)', marginBottom: 16, letterSpacing: '-0.02em' }}>
                {clinicInfo?.aboutTitle || <>Committed to <em style={{ fontStyle: 'italic', color: 'var(--teal)' }}>Excellence</em></>}
              </h2>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 14, background: 'var(--teal-pale)', borderRadius: 12, padding: '16px 20px', border: '1px solid var(--teal-pale2)', marginBottom: 20 }}>
                <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'var(--teal)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 22, flexShrink: 0 }}>👨‍⚕️</div>
                <div>
                  <strong style={{ display: 'block', fontSize: 16, fontWeight: 700, color: 'var(--teal)' }}>Dr. Sumeet Gupta</strong>
                  <span style={{ fontSize: 12, color: 'var(--muted)' }}>BDS, MDS — Dental Implantologist & Smile Design Specialist</span>
                </div>
              </div>
              <p style={{ fontSize: 15.5, color: 'var(--mid)', lineHeight: 1.85, marginBottom: 16 }}>
                {clinicInfo?.aboutDescription || 'With over 13 years of experience and thousands of successful treatments, Dr. Sumeet Gupta is dedicated to providing world-class dental care with a personal touch — Experienced. Passionate. Committed to Excellence.'}
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 24 }}>
                {['Advanced 3D Digital Scanning', 'Painless Needle-Less Techniques', 'International Sterilization', 'Open 24/7 including Emergencies', 'Transparent Pricing', '2,000+ Happy Patients'].map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, fontSize: 13.5, color: 'var(--mid)' }}>
                    <div className="check" style={{ marginTop: 1 }}>✓</div>{f}
                  </div>
                ))}
              </div>
              <Link href="/about" className="btn btn-teal">Learn More About Us →</Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="section section-alt">
        <div className="container">
          <div className="section-head">
            <div className="eyebrow">Patient Stories</div>
            <h2>What Our Patients Say</h2>
            <div className="gold-line" />
            <p style={{ marginTop: 16 }}>4.9★ · 59 verified Google reviews</p>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 20 }}>
            {(testimonials.length > 0 ? testimonials : defaultTestimonials).map((t, i) => (
              <div key={t._id || i} style={{ background: i === 0 ? 'var(--teal-dark)' : '#fff', borderRadius: 14, padding: 28, border: `1px solid ${i === 0 ? 'var(--teal-dark)' : 'var(--border)'}`, borderTop: `3px solid ${i === 0 ? 'var(--gold)' : 'var(--teal-pale2)'}` }}>
                <div className="stars">{Array.from({ length: t.rating || 5 }).map((_, j) => <span key={j} className="star">★</span>)}</div>
                <p style={{ fontSize: 14, color: i === 0 ? 'rgba(255,255,255,0.82)' : 'var(--mid)', fontStyle: 'italic', lineHeight: 1.8, margin: '12px 0 18px' }}>"{t.review}"</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 40, height: 40, borderRadius: '50%', background: i === 0 ? 'rgba(255,255,255,0.15)' : 'var(--teal-pale)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>😊</div>
                  <div>
                    <strong style={{ fontSize: 13, fontWeight: 700, display: 'block', color: i === 0 ? '#fff' : 'var(--charcoal)' }}>{t.patientName}</strong>
                    <span style={{ fontSize: 11, color: i === 0 ? 'rgba(255,255,255,0.5)' : 'var(--muted)' }}>{t.service}{t.location ? ` · ${t.location}` : ''}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div style={{ textAlign: 'center', marginTop: 36 }}>
            <Link href="/testimonials" className="btn btn-teal">See All Reviews →</Link>
          </div>
        </div>
      </section>

      {/* ── BLOG ── */}
      {posts.length > 0 && (
        <section className="section">
          <div className="container">
            <div className="section-head">
              <div className="eyebrow">Dental Knowledge</div>
              <h2>From Our Blog</h2>
              <div className="gold-line" />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))', gap: 24 }}>
              {posts.map((post) => (
                <Link key={post._id} href={`/blog/${post.slug.current}`} style={{ background: '#fff', borderRadius: 14, overflow: 'hidden', border: '1px solid var(--border)', textDecoration: 'none', display: 'block', transition: 'all 0.25s' }} className="card-hover">
                  {post.mainImage && (
                    <div style={{ height: 200, overflow: 'hidden', position: 'relative' }}>
                      <Image src={urlFor(post.mainImage).width(600).height(400).url()} alt={post.mainImage.alt || post.title} fill style={{ objectFit: 'cover' }} />
                    </div>
                  )}
                  <div style={{ padding: 22 }}>
                    <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 8 }}>{post.category}</div>
                    <h3 style={{ fontSize: 17, fontWeight: 700, marginBottom: 8, lineHeight: 1.35 }}>{post.title}</h3>
                    <p style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.7, marginBottom: 14 }}>{post.excerpt}</p>
                    <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--teal)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>Read Article →</span>
                  </div>
                </Link>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: 36 }}>
              <Link href="/blog" className="btn btn-teal">View All Articles →</Link>
            </div>
          </div>
        </section>
      )}

      {/* ── CTA BANNER ── */}
      <section className="section section-alt">
        <div className="container">
          <div className="cta-banner">
            <div>
              <h2>Your Smile. Our Passion. <em style={{ fontStyle: 'italic', color: 'var(--gold-light)' }}>Together, We Create Confidence.</em></h2>
              <p>Join 2,000+ happy patients across Chandigarh. Book your free consultation today.</p>
            </div>
            <div className="cta-btns">
              <Link href="/contact" className="btn btn-white">📅 Book Free Consult</Link>
              <a href={`tel:+91${phone}`} className="btn btn-outline-white">📞 {phone}</a>
            </div>
          </div>
        </div>
      </section>

      <style>{`
        @media(max-width:960px) {
          section > div[style*="grid-template-columns: 1fr 400px"] { grid-template-columns: 1fr !important; }
          section > div[style*="grid-template-columns: 1fr 1fr"] { grid-template-columns: 1fr !important; }
          section > div[style*="grid-template-columns: repeat(4"] { grid-template-columns: 1fr 1fr !important; }
        }
      `}</style>
    </>
  )
}

function QuickForm({ services, phone }) {
  return (
    <form action="/contact" method="get">
      <div style={{ marginBottom: 10 }}>
        <select name="service" style={{ width: '100%', padding: '11px 14px', border: '1.5px solid var(--border)', borderRadius: 8, fontFamily: 'inherit', fontSize: 13.5, color: 'var(--charcoal)', background: 'var(--bg)', outline: 'none' }}>
          <option value="">Select Service...</option>
          {(services.length > 0 ? services : defaultServices).map(s => (
            <option key={s.title} value={s.slug?.current || s.title}>{s.title}</option>
          ))}
        </select>
      </div>
      <div style={{ marginBottom: 12 }}>
        <input type="date" name="date" style={{ width: '100%', padding: '11px 14px', border: '1.5px solid var(--border)', borderRadius: 8, fontFamily: 'inherit', fontSize: 13.5, background: 'var(--bg)', outline: 'none' }} />
      </div>
      <button type="submit" className="btn btn-teal" style={{ width: '100%', justifyContent: 'center', padding: 13 }}>Confirm Booking →</button>
    </form>
  )
}

const defaultServices = [
  { title: 'Dental Implants', slug: { current: 'dental-implants' }, icon: '🦷', shortDescription: 'Permanent tooth replacement' },
  { title: 'Smile Designing', slug: { current: 'smile-designing' }, icon: '✨', shortDescription: 'Complete smile makeovers' },
  { title: 'Dental Scaling', slug: { current: 'dental-scaling' }, icon: '🪥', shortDescription: 'Deep cleaning & whitening' },
  { title: 'Pediatric Dentistry', slug: { current: 'pediatric-dentistry' }, icon: '🧒', shortDescription: 'Gentle care for children' },
  { title: 'Root Canal', slug: { current: 'root-canal' }, icon: '🩺', shortDescription: 'Painless single-visit RCT' },
  { title: 'Crowns & Bridges', slug: { current: 'crowns-bridges' }, icon: '👑', shortDescription: 'Restore strength & function' },
  { title: 'Orthodontics', slug: { current: 'orthodontics' }, icon: '😁', shortDescription: 'Braces & Invisalign' },
  { title: 'Emergency Care', slug: { current: 'emergency' }, icon: '🚨', shortDescription: '24/7 same-day appointments' },
]

const defaultTestimonials = [
  { patientName: 'Priya S.', service: 'Root Canal', rating: 5, review: 'The painless RCT was a revelation — I felt absolutely nothing. The team at Smile Dental Sector 38 are magicians.' },
  { patientName: 'Sunita K.', service: 'Dental Implant', rating: 5, review: 'Got an implant after years of hiding my smile. Now I can\'t stop smiling! Best dental clinic in Chandigarh.' },
  { patientName: 'Arjun D.', service: 'Emergency Care', rating: 5, review: 'Emergency at 2AM — they answered, I was seen within the hour. Incredible 24/7 service.' },
]
