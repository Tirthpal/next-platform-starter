import Link from 'next/link'

export default function NotFound() {
  return (
    <div style={{ textAlign: 'center', padding: '120px 24px' }}>
      <div style={{ fontSize: 72, marginBottom: 20 }}>🦷</div>
      <h1 style={{ fontSize: 48, fontWeight: 800, color: 'var(--teal)', marginBottom: 12 }}>404</h1>
      <h2 style={{ fontSize: 24, marginBottom: 12 }}>Page Not Found</h2>
      <p style={{ color: 'var(--muted)', fontSize: 16, marginBottom: 32 }}>The page you're looking for doesn't exist or has been moved.</p>
      <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
        <Link href="/" className="btn btn-teal">Go Home</Link>
        <Link href="/contact" className="btn btn-gold">Book Appointment</Link>
      </div>
    </div>
  )
}
